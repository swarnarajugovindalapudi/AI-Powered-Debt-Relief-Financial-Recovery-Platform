import { useNavigate } from "react-router-dom";

function Dashboard() {
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("access_token");
    navigate("/login");
  };

  const cardStyle = {
    background: "#ffffff",
    padding: "20px",
    borderRadius: "12px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
    flex: 1,
    minWidth: "220px",
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#f4f7fb",
        fontFamily: "Arial, sans-serif",
      }}
    >
      {/* Header */}
      <div
        style={{
          background: "#1e3a8a",
          color: "white",
          padding: "20px 40px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <div>
          <h2>FinRelief AI Dashboard</h2>
          <p>AI Powered Debt Relief & Financial Recovery Platform</p>
        </div>

        <button
          onClick={logout}
          style={{
            padding: "10px 18px",
            background: "#ef4444",
            border: "none",
            color: "white",
            borderRadius: "8px",
            cursor: "pointer",
          }}
        >
          Logout
        </button>
      </div>

      {/* Cards */}
      <div
        style={{
          display: "flex",
          gap: "20px",
          padding: "30px",
          flexWrap: "wrap",
        }}
      >
        <div style={cardStyle}>
          <h3>Total Debt</h3>
          <h1>₹5,20,000</h1>
        </div>

        <div style={cardStyle}>
          <h3>Monthly EMI</h3>
          <h1>₹21,000</h1>
        </div>

        <div style={cardStyle}>
          <h3>Financial Health</h3>
          <h1>Moderate</h1>
        </div>

        <div style={cardStyle}>
          <h3>Settlement Chance</h3>
          <h1>70%</h1>
        </div>
      </div>

      {/* Features */}
      <div style={{ padding: "0 30px 30px" }}>
        <div
          style={{
            background: "white",
            borderRadius: "12px",
            padding: "25px",
            boxShadow: "0 4px 12px rgba(0,0,0,.08)",
          }}
        >
          <h2>Platform Features</h2>

          <ul style={{ lineHeight: "2" }}>
            <li>✅ Financial Health Analysis</li>
            <li>✅ Settlement Prediction</li>
            <li>✅ AI Negotiation Letter Generator</li>
            <li>✅ Borrower Rights Information</li>
            <li>✅ Loan Summary Dashboard</li>
            <li>✅ FastAPI Backend Integration Ready</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;