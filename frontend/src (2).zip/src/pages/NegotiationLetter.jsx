function NegotiationLetter() {
  return <h1>AI Negotiation Letter</h1>;
}

export default NegotiationLetter;