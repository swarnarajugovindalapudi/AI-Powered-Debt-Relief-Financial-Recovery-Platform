function SettlementPredictor() {
  return <h1>Settlement Predictor</h1>;
}

export default SettlementPredictor;